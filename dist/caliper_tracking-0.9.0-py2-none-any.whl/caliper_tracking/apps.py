from django.apps import AppConfig


class CaliperTrackingConfig(AppConfig):
    name = 'caliper_tracking'
    verbose_name = "Caliper Tracking"
